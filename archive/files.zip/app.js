const API_BASE = 'http://localhost:8000/api/v1/version-control';

const state = {
    prompts: [],
    selectedPromptId: null,
    selectedPrompt: null,
    versionHistory: [],
    confirmCallback: null
};

const elements = {
    healthDot: document.getElementById('healthDot'),
    healthText: document.getElementById('healthText'),
    promptList: document.getElementById('promptList'),
    welcomeScreen: document.getElementById('welcomeScreen'),
    promptView: document.getElementById('promptView'),
    promptKey: document.getElementById('promptKey'),
    promptTitle: document.getElementById('promptTitle'),
    promptDescription: document.getElementById('promptDescription'),
    promptText: document.getElementById('promptText'),
    modelSettings: document.getElementById('modelSettings'),
    changeNote: document.getElementById('changeNote'),
    versionCount: document.getElementById('versionCount'),
    versionList: document.getElementById('versionList'),
    btnCreatePrompt: document.getElementById('btnCreatePrompt'),
    btnSaveVersion: document.getElementById('btnSaveVersion'),
    btnDeletePrompt: document.getElementById('btnDeletePrompt'),
    createPromptModal: document.getElementById('createPromptModal'),
    confirmModal: document.getElementById('confirmModal'),
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toastMessage')
};

async function checkHealth() {
    try {
        const response = await fetch(`${API_BASE}/prompts`);
        if (response.ok) {
            elements.healthDot.classList.add('online');
            elements.healthDot.classList.remove('offline');
            elements.healthText.textContent = 'Online';
            return true;
        }
    } catch (error) {
        console.error('Health check failed:', error);
    }
    elements.healthDot.classList.add('offline');
    elements.healthDot.classList.remove('online');
    elements.healthText.textContent = 'Offline';
    return false;
}

async function fetchPrompts() {
    try {
        const response = await fetch(`${API_BASE}/prompts`);
        if (!response.ok) {
            throw new Error(`Failed to fetch prompts: ${response.status}`);
        }
        state.prompts = await response.json();
        renderPromptList();
        console.log('Fetched prompts:', state.prompts);
    } catch (error) {
        console.error('Error fetching prompts:', error);
        showToast('Failed to load prompts');
    }
}

function renderPromptList() {
    if (state.prompts.length === 0) {
        elements.promptList.innerHTML = '<div class="empty-state">No prompts yet</div>';
        return;
    }

    elements.promptList.innerHTML = state.prompts.map(prompt => `
        <div class="prompt-item ${state.selectedPromptId === prompt.id ? 'active' : ''}" data-id="${prompt.id}">
            <div class="prompt-item-key">${escapeHtml(prompt.key)}</div>
            <div class="prompt-item-title">${escapeHtml(prompt.title)}</div>
            <div class="prompt-item-description">${escapeHtml(prompt.description || '')}</div>
        </div>
    `).join('');

    document.querySelectorAll('.prompt-item').forEach(item => {
        item.addEventListener('click', () => {
            const promptId = parseInt(item.dataset.id);
            selectPrompt(promptId);
        });
    });
}

async function selectPrompt(promptId) {
    state.selectedPromptId = promptId;
    renderPromptList();

    try {
        await fetchPromptDetails(promptId);
        await fetchVersionHistory(promptId);
        showPromptView();
    } catch (error) {
        console.error('Error selecting prompt:', error);
        showToast('Failed to load prompt details');
    }
}

async function fetchPromptDetails(promptId) {
    try {
        const response = await fetch(`${API_BASE}/prompts/${promptId}`);
        if (!response.ok) {
            throw new Error(`Failed to fetch prompt details: ${response.status}`);
        }
        state.selectedPrompt = await response.json();
        renderPromptDetails();
        console.log('Fetched prompt details:', state.selectedPrompt);
    } catch (error) {
        console.error('Error fetching prompt details:', error);
        throw error;
    }
}

function renderPromptDetails() {
    if (!state.selectedPrompt) return;

    elements.promptKey.textContent = state.selectedPrompt.key;
    elements.promptTitle.textContent = state.selectedPrompt.title;
    elements.promptDescription.textContent = state.selectedPrompt.description || '';

    const latestVersion = state.selectedPrompt.latest_version;
    if (latestVersion) {
        elements.promptText.value = latestVersion.prompt_text || '';
        elements.modelSettings.value = latestVersion.model_settings 
            ? JSON.stringify(latestVersion.model_settings, null, 2) 
            : '';
    } else {
        elements.promptText.value = '';
        elements.modelSettings.value = '';
    }
    elements.changeNote.value = '';
}

async function fetchVersionHistory(promptId) {
    try {
        const response = await fetch(`${API_BASE}/versions/${promptId}/history`);
        if (!response.ok) {
            throw new Error(`Failed to fetch version history: ${response.status}`);
        }
        state.versionHistory = await response.json();
        renderVersionHistory();
        console.log('Fetched version history:', state.versionHistory);
    } catch (error) {
        console.error('Error fetching version history:', error);
        throw error;
    }
}

function renderVersionHistory() {
    const count = state.versionHistory.length;
    elements.versionCount.textContent = `${count} version${count !== 1 ? 's' : ''}`;

    if (count === 0) {
        elements.versionList.innerHTML = '<div class="empty-state">No versions yet</div>';
        return;
    }

    elements.versionList.innerHTML = state.versionHistory.map((version, index) => {
        const versionNumber = count - index;
        const timestamp = new Date(version.created_at).toLocaleString();
        
        return `
            <div class="version-item">
                <div class="version-header">
                    <span class="version-number">Version ${versionNumber}</span>
                    <span class="version-timestamp">${timestamp}</span>
                </div>
                ${version.change_note ? `<div class="version-change-note">"${escapeHtml(version.change_note)}"</div>` : ''}
                <div class="version-details">
                    <div class="version-detail-label">Prompt Text</div>
                    <div class="version-text">${escapeHtml(version.prompt_text || '')}</div>
                </div>
                <div class="version-details">
                    <div class="version-detail-label">Model Settings</div>
                    <div class="version-settings">${escapeHtml(JSON.stringify(version.model_settings, null, 2))}</div>
                </div>
                <div class="version-actions">
                    <button class="btn-danger btn-small" onclick="confirmDeleteVersion(${version.id})">Delete</button>
                </div>
            </div>
        `;
    }).join('');
}

function showPromptView() {
    elements.welcomeScreen.style.display = 'none';
    elements.promptView.style.display = 'block';
}

function showWelcomeScreen() {
    elements.welcomeScreen.style.display = 'flex';
    elements.promptView.style.display = 'none';
}

async function createPrompt(key, title, description) {
    try {
        const response = await fetch(`${API_BASE}/prompts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ key, title, description })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || `Failed to create prompt: ${response.status}`);
        }

        const newPrompt = await response.json();
        console.log('Created prompt:', newPrompt);
        showToast('Prompt created successfully');
        await fetchPrompts();
        selectPrompt(newPrompt.id);
    } catch (error) {
        console.error('Error creating prompt:', error);
        showToast(`Failed to create prompt: ${error.message}`);
        throw error;
    }
}

async function createVersion(promptId, promptText, modelSettings, changeNote) {
    try {
        let parsedSettings;
        try {
            parsedSettings = modelSettings.trim() ? JSON.parse(modelSettings) : {};
        } catch (e) {
            throw new Error('Invalid JSON in model settings');
        }

        const response = await fetch(`${API_BASE}/versions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                prompt_id: promptId,
                prompt_text: promptText,
                model_settings: parsedSettings,
                change_note: changeNote
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || `Failed to create version: ${response.status}`);
        }

        const newVersion = await response.json();
        console.log('Created version:', newVersion);
        showToast('New version created successfully');
        await fetchPromptDetails(promptId);
        await fetchVersionHistory(promptId);
        elements.changeNote.value = '';
    } catch (error) {
        console.error('Error creating version:', error);
        showToast(`Failed to create version: ${error.message}`);
        throw error;
    }
}

async function deletePrompt(promptId) {
    try {
        const response = await fetch(`${API_BASE}/prompts/${promptId}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error(`Failed to delete prompt: ${response.status}`);
        }

        console.log('Deleted prompt:', promptId);
        showToast('Prompt deleted successfully');
        state.selectedPromptId = null;
        state.selectedPrompt = null;
        await fetchPrompts();
        showWelcomeScreen();
    } catch (error) {
        console.error('Error deleting prompt:', error);
        showToast('Failed to delete prompt');
        throw error;
    }
}

async function deleteVersion(versionId) {
    try {
        const response = await fetch(`${API_BASE}/versions/${versionId}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error(`Failed to delete version: ${response.status}`);
        }

        console.log('Deleted version:', versionId);
        showToast('Version deleted successfully');
        
        if (state.selectedPromptId) {
            await fetchPromptDetails(state.selectedPromptId);
            await fetchVersionHistory(state.selectedPromptId);
        }
    } catch (error) {
        console.error('Error deleting version:', error);
        showToast('Failed to delete version');
        throw error;
    }
}

function showCreatePromptModal() {
    elements.createPromptModal.classList.add('active');
    document.getElementById('newPromptKey').value = '';
    document.getElementById('newPromptTitle').value = '';
    document.getElementById('newPromptDescription').value = '';
}

function closeCreatePromptModal() {
    elements.createPromptModal.classList.remove('active');
}

function showConfirmModal(title, message, callback) {
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    state.confirmCallback = callback;
    elements.confirmModal.classList.add('active');
}

function closeConfirmModal() {
    elements.confirmModal.classList.remove('active');
    state.confirmCallback = null;
}

function confirmDeletePrompt() {
    if (!state.selectedPromptId) return;
    showConfirmModal(
        'Delete Prompt',
        'Are you sure you want to delete this prompt? This will delete all versions and cannot be undone.',
        () => deletePrompt(state.selectedPromptId)
    );
}

function confirmDeleteVersion(versionId) {
    showConfirmModal(
        'Delete Version',
        'Are you sure you want to delete this version? This action cannot be undone.',
        () => deleteVersion(versionId)
    );
}

function showToast(message) {
    elements.toastMessage.textContent = message;
    elements.toast.classList.add('show');
    setTimeout(() => {
        elements.toast.classList.remove('show');
    }, 3000);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

elements.btnCreatePrompt.addEventListener('click', showCreatePromptModal);

document.getElementById('btnCloseCreateModal').addEventListener('click', closeCreatePromptModal);
document.getElementById('btnCancelCreate').addEventListener('click', closeCreatePromptModal);

document.getElementById('btnConfirmCreate').addEventListener('click', async () => {
    const key = document.getElementById('newPromptKey').value.trim();
    const title = document.getElementById('newPromptTitle').value.trim();
    const description = document.getElementById('newPromptDescription').value.trim();

    if (!key || !title) {
        showToast('Key and title are required');
        return;
    }

    try {
        await createPrompt(key, title, description);
        closeCreatePromptModal();
    } catch (error) {
    }
});

elements.btnSaveVersion.addEventListener('click', async () => {
    if (!state.selectedPromptId) return;

    const promptText = elements.promptText.value.trim();
    const modelSettings = elements.modelSettings.value.trim();
    const changeNote = elements.changeNote.value.trim();

    if (!promptText) {
        showToast('Prompt text is required');
        return;
    }

    if (!changeNote) {
        showToast('Change note is required');
        return;
    }

    try {
        await createVersion(state.selectedPromptId, promptText, modelSettings, changeNote);
    } catch (error) {
    }
});

elements.btnDeletePrompt.addEventListener('click', confirmDeletePrompt);

document.getElementById('btnCloseConfirmModal').addEventListener('click', closeConfirmModal);
document.getElementById('btnCancelConfirm').addEventListener('click', closeConfirmModal);

document.getElementById('btnConfirmAction').addEventListener('click', async () => {
    if (state.confirmCallback) {
        try {
            await state.confirmCallback();
            closeConfirmModal();
        } catch (error) {
        }
    }
});

elements.createPromptModal.addEventListener('click', (e) => {
    if (e.target === elements.createPromptModal) {
        closeCreatePromptModal();
    }
});

elements.confirmModal.addEventListener('click', (e) => {
    if (e.target === elements.confirmModal) {
        closeConfirmModal();
    }
});

async function init() {
    console.log('Initializing Chronicle GUI...');
    const isHealthy = await checkHealth();
    if (isHealthy) {
        await fetchPrompts();
    }
}

init();
